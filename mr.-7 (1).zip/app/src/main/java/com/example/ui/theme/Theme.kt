package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MR7ColorScheme = darkColorScheme(
    primary = AntiqueGoldBright,
    onPrimary = Color.Black,
    primaryContainer = AntiqueGoldDeep,
    onPrimaryContainer = Color.White,
    secondary = AntiqueGold,
    onSecondary = Color.Black,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = WarmChampagne,
    tertiary = NeonCyan,
    onTertiary = Color.Black,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderGlass,
    error = Color(0xFFEF4444),
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MR7ColorScheme,
        typography = Typography,
        content = content
    )
}
