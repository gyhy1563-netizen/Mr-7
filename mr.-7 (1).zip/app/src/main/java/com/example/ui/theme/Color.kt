package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// ============================================
//  WARM LUXURY YELLOW-TINTED PALETTE (یلو یلو سی شیڈ)
// ============================================
val MatteBlackBg = Color(0xFF141206)
val DarkBg = Color(0xFF141206)
val DarkSurface = Color(0xFF1E1A08)
val DarkSurfaceVariant = Color(0xFF2B240B)
val DarkCardBg = Color(0xFF231E09)

// Glassmorphic translucent surfaces with warm yellow tint
val GlassBg = Color(0xE61E1906)
val GlassSurface = Color(0xD926200A)
val GlassCard = Color(0xF2201B08)

// ============================================
//  VIBRANT YELLOW & GOLD SPECTRUM
// ============================================
val AntiqueGold = Color(0xFFFBBF24)
val AntiqueGoldBright = Color(0xFFFDE047)
val AntiqueGoldLight = Color(0xFFFEF08A)
val AntiqueGoldDark = Color(0xFFEAB308)
val AntiqueGoldDeep = Color(0xFFCA8A04)
val WarmChampagne = Color(0xFFFEF3C7)
val YellowGlow = Color(0xFFFFE066)

// Vibrant Complementary Accents
val ElectricViolet = Color(0xFF8B5CF6)
val ElectricVioletLight = Color(0xFFA78BFA)
val NeonCyan = Color(0xFF06B6D4)
val NeonCyanLight = Color(0xFF67E8F9)
val HotPink = Color(0xFFF43F5E)
val EmeraldGreen = Color(0xFF10B981)

// High-Contrast Crisp Typography (Warm yellow-tinted white for luxurious readability)
val TextPrimary = Color(0xFFFFFBEB)
val TextSecondary = Color(0xFFD4CA9C)
val TextTertiary = Color(0xFFA19770)

// Polished Glass & Yellow Hairline Borders
val BorderGlass = Color(0x38FDE047)
val BorderGlassMuted = Color(0x22FACC15)
val BorderGold = Color(0x80FDE047)
val BorderGoldGlow = Color(0xCCFBBF24)

// ============================================
//  LUXURY YELLOW GRADIENTS & POLISHED METALLIC BRUSHES
// ============================================
val YellowBackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF262006),
        Color(0xFF181507),
        Color(0xFF121005)
    )
)

val GoldGradient = Brush.horizontalGradient(
    colors = listOf(AntiqueGoldDeep, AntiqueGoldBright, AntiqueGold, AntiqueGoldLight, AntiqueGoldDark)
)

val LiquidGoldGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFFCA8A04),
        Color(0xFFFDE047),
        Color(0xFFFEF08A),
        Color(0xFFFBBF24),
        Color(0xFFEAB308)
    )
)

val GlassGoldBorderBrush = Brush.linearGradient(
    colors = listOf(
        Color(0xCCFDE047),
        Color(0x44FFFFFF),
        Color(0x88CA8A04),
        Color(0x33FDE047),
        Color(0xAAFABF24)
    )
)

val GlassCardBorderBrush = Brush.linearGradient(
    colors = listOf(
        Color(0x99FDE047),
        Color(0x55EAB308),
        Color(0x33CA8A04),
        Color(0x33FDE047)
    )
)

val HeroVignetteGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0x15141206),
        Color(0xA6141206),
        Color(0xFA141206)
    )
)

val CardGlowGradient = Brush.verticalGradient(
    colors = listOf(Color(0x33FDE047), Color(0x0A141206))
)

// ============================================
//  ANIMATED YELLOW-GOLD GRADIENT HELPER
// ============================================
@Composable
fun rememberAnimatedGoldGradient(): Brush {
    val infiniteTransition = rememberInfiniteTransition(label = "gold_shimmer")
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )
    return Brush.linearGradient(
        colors = listOf(
            AntiqueGoldDark,
            AntiqueGold,
            AntiqueGoldLight,
            Color.White.copy(alpha = 0.95f),
            AntiqueGoldBright,
            AntiqueGoldDark
        ),
        start = Offset(offset - 600f, offset - 600f),
        end = Offset(offset + 600f, offset + 600f)
    )
}
