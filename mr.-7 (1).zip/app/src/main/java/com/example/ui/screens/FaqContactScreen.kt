package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentConfig
import com.example.ui.theme.*
import com.example.ui.viewmodel.StoreViewModel

data class FaqItem(val question: String, val answer: String)

@Composable
fun FaqContactScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val faqs = remember {
        listOf(
            FaqItem(
                question = "How do I place an order?",
                answer = "Browse our UK Accounts or TikTok Coins packages, click 'BUY NOW', enter your name and WhatsApp number, select your payment method (Easypaisa, SadaPay, Meezan Bank, or Cash On Delivery), and submit. You can confirm directly on WhatsApp."
            ),
            FaqItem(
                question = "What payment methods are available?",
                answer = "We support Easypaisa (Abdul Rehman Ahmad: 0348-3025-551), SadaPay (Muhammad Yasir Hussain: 0309-490-2077), Meezan Bank (Abdul Rehman Ahmad: 00-3 00-11 31 30 3 03), and Cash on Delivery (COD) with WhatsApp coordination."
            ),
            FaqItem(
                question = "How do I send payment proof?",
                answer = "When completing your order in the checkout sheet, copy the Transaction ID from your banking app/SMS into the field, and attach the screenshot receipt. Once submitted, our team verifies it in minutes."
            ),
            FaqItem(
                question = "How does the UK account package work?",
                answer = "You receive an official UK TikTok Creator Rewards account with live streaming permissions already unlocked. This lets you monetize your videos in British Pounds (GBP) from Pakistan."
            ),
            FaqItem(
                question = "How do I purchase custom coin quantities?",
                answer = "Open our 'TikTok Coins' section and use the interactive Coin Calculator. Enter any coin count (e.g., 500, 10,000, 200,000) and click 'BUY NOW' to check out with your exact calculated price."
            ),
            FaqItem(
                question = "How long does order processing take?",
                answer = "Coin recharges are typically fulfilled within 5 to 15 minutes. UK account credentials and full onboarding support are delivered within 1 to 2 hours."
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Helpline Hero Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("contact_helpline_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                border = BorderStroke(
                    1.5.dp,
                    Brush.linearGradient(listOf(AntiqueGoldBright, AntiqueGoldDark, WarmChampagne))
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(AntiqueGoldBright, AntiqueGoldDark))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HeadsetMic,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "MR. 7 HELPLINE",
                                color = AntiqueGoldBright,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "24/7 Dedicated Support",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Need help with TikTok UK account login, coin recharge, or live gifting? Contact our direct priority line:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    // Buttons: WhatsApp and Email
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.openWhatsAppChat(context) },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("helpline_whatsapp_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Chat,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WhatsApp",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Button(
                            onClick = { viewModel.openEmailSupport(context) },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("helpline_email_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                            border = BorderStroke(1.dp, BorderGlass),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = null,
                                tint = AntiqueGoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Email Support",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "WhatsApp: ${PaymentConfig.SUPPORT_WHATSAPP}  •  Email: ${PaymentConfig.SUPPORT_EMAIL}",
                        color = TextTertiary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Trust Badges Grid
        item {
            Text(
                text = "Why Choose MR. 7?",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TrustBadge(
                    icon = Icons.Default.Speed,
                    title = "Fast Support",
                    desc = "Average 5m response",
                    modifier = Modifier.weight(1f)
                )
                TrustBadge(
                    icon = Icons.Default.Security,
                    title = "Secure Checkout",
                    desc = "Verified manual transfers",
                    modifier = Modifier.weight(1f)
                )
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TrustBadge(
                    icon = Icons.Default.Star,
                    title = "Top Rated",
                    desc = "4.9★ Creator satisfaction",
                    modifier = Modifier.weight(1f)
                )
                TrustBadge(
                    icon = Icons.Default.SupportAgent,
                    title = "Order Help",
                    desc = "WhatsApp assistance",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Frequently Asked Questions
        item {
            Text(
                text = "Frequently Asked Questions",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(faqs) { faq ->
            FaqAccordion(faq = faq)
        }
    }
}

@Composable
fun TrustBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = DarkSurfaceVariant,
        border = BorderStroke(1.dp, BorderGlass)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AntiqueGoldBright,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
fun FaqAccordion(faq: FaqItem) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCardBg),
        border = BorderStroke(1.dp, if (expanded) BorderGold else BorderGlass)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = faq.question,
                    color = if (expanded) AntiqueGoldLight else Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }
            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    HorizontalDivider(color = BorderGlass)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = faq.answer,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
