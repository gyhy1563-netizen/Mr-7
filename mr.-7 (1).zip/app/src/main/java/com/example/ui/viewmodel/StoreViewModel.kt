package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.OrderEntity
import com.example.data.local.WishlistEntity
import com.example.data.model.CoinPricing
import com.example.data.model.PaymentConfig
import com.example.data.model.Product
import com.example.data.model.ProductCatalog
import com.example.data.model.Review
import com.example.data.model.UserProfile
import com.example.data.repository.StoreRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.net.URLEncoder

sealed class AppScreen {
    object Store : AppScreen()
    data class ProductDetail(val product: Product) : AppScreen()
    object Coins : AppScreen()
    object Wishlist : AppScreen()
    object Orders : AppScreen()
    object Profile : AppScreen()
    object SupportFaq : AppScreen()
}

class StoreViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = StoreRepository(database.appDao())

    // Navigation state
    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Store)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Search and Category filtering
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Real-time filtered products
    val filteredProducts: StateFlow<List<Product>> = combine(
        _searchQuery,
        _selectedCategory
    ) { query, category ->
        ProductCatalog.allProducts.filter { product ->
            val matchesCategory = category == "All" || product.category.equals(category, ignoreCase = true)
            val matchesQuery = query.isBlank() ||
                    product.title.contains(query, ignoreCase = true) ||
                    product.category.contains(query, ignoreCase = true) ||
                    product.description.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProductCatalog.allProducts)

    // Wishlist items
    val wishlistItems: StateFlow<List<WishlistEntity>> = repository.wishlistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Orders history
    val ordersList: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Profile
    val userProfile: StateFlow<UserProfile> = repository.currentUser

    // Cart state
    private val _cart = MutableStateFlow<Map<String, Int>>(emptyMap())
    val cart: StateFlow<Map<String, Int>> = _cart.asStateFlow()
    val cartItemCount: StateFlow<Int> = _cart.map { map ->
        map.values.sum()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Custom Coin Calculator state
    private val _customCoinsInput = MutableStateFlow("235")
    val customCoinsInput: StateFlow<String> = _customCoinsInput.asStateFlow()

    private val _calculatedCoinPrice = MutableStateFlow<Long>(CoinPricing.calculatePrice(235))
    val calculatedCoinPrice: StateFlow<Long> = _calculatedCoinPrice.asStateFlow()

    // Checkout Modal State
    data class CheckoutData(
        val productTitle: String,
        val unitPrice: Long,
        val quantity: Int = 1,
        val totalAmount: Long = unitPrice,
        val isCoinCustom: Boolean = false
    )

    private val _activeCheckout = MutableStateFlow<CheckoutData?>(null)
    val activeCheckout: StateFlow<CheckoutData?> = _activeCheckout.asStateFlow()

    // Latest created order for confirmation dialog/screen
    private val _lastSubmittedOrder = MutableStateFlow<OrderEntity?>(null)
    val lastSubmittedOrder: StateFlow<OrderEntity?> = _lastSubmittedOrder.asStateFlow()

    // Product reviews flow
    fun getProductReviews(productId: String): Flow<List<Review>> = repository.getReviews(productId)
    fun isWishlisted(productId: String): Flow<Boolean> = repository.isProductWishlisted(productId)

    // Navigation actions
    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        return if (_currentScreen.value !is AppScreen.Store) {
            _currentScreen.value = AppScreen.Store
            true
        } else {
            false
        }
    }

    fun openProductDetail(product: Product) {
        _currentScreen.value = AppScreen.ProductDetail(product)
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleWishlist(product: Product, currentlyWishlisted: Boolean) {
        viewModelScope.launch {
            try {
                repository.toggleWishlist(product, currentlyWishlisted)
                val message = if (currentlyWishlisted) "Removed from Wishlist" else "Added to Wishlist"
                Toast.makeText(getApplication(), message, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun addToCart(product: Product) {
        val current = _cart.value.toMutableMap()
        current[product.id] = (current[product.id] ?: 0) + 1
        _cart.value = current
        Toast.makeText(getApplication(), "Added to Cart", Toast.LENGTH_SHORT).show()
    }

    fun updateCoinsInput(input: String) {
        val sanitized = input.filter { it.isDigit() }.take(9)
        _customCoinsInput.value = sanitized
        val count = sanitized.toLongOrNull() ?: 0L
        _calculatedCoinPrice.value = CoinPricing.calculatePrice(count)
    }

    fun selectCoinPreset(coins: Long) {
        _customCoinsInput.value = coins.toString()
        _calculatedCoinPrice.value = CoinPricing.calculatePrice(coins)
    }

    // Checkout actions
    fun startCheckoutForProduct(product: Product, quantity: Int = 1) {
        _activeCheckout.value = CheckoutData(
            productTitle = product.title,
            unitPrice = product.price.toLong(),
            quantity = quantity,
            totalAmount = product.price.toLong() * quantity,
            isCoinCustom = false
        )
    }

    fun startCheckoutForCustomCoins(coins: Long, price: Long) {
        if (coins <= 0) return
        _activeCheckout.value = CheckoutData(
            productTitle = "$coins TikTok Coins (Custom Order)",
            unitPrice = price,
            quantity = 1,
            totalAmount = price,
            isCoinCustom = true
        )
    }

    fun closeCheckout() {
        _activeCheckout.value = null
    }

    fun dismissOrderConfirmation() {
        _lastSubmittedOrder.value = null
    }

    fun submitOrder(
        customerName: String,
        phoneNumber: String,
        productName: String,
        quantity: Int,
        totalAmount: Long,
        paymentMethod: String,
        transactionId: String,
        screenshotUri: String?,
        notes: String,
        onSuccess: (OrderEntity) -> Unit
    ) {
        viewModelScope.launch {
            try {
                val order = repository.createOrder(
                    customerName = customerName,
                    phoneNumber = phoneNumber,
                    productName = productName,
                    quantity = quantity,
                    totalAmount = totalAmount,
                    paymentMethod = paymentMethod,
                    transactionId = transactionId,
                    screenshotUri = screenshotUri,
                    notes = notes
                )
                _lastSubmittedOrder.value = order
                _activeCheckout.value = null
                onSuccess(order)
            } catch (e: Exception) {
                Toast.makeText(getApplication(), "Failed to place order: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun submitReview(productId: String, author: String, rating: Int, comment: String) {
        viewModelScope.launch {
            try {
                repository.addReview(productId, author, rating, comment)
                Toast.makeText(getApplication(), "Review submitted successfully!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(getApplication(), "Failed to submit review", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun login(name: String, email: String, phone: String) {
        repository.loginUser(name, email, phone)
        Toast.makeText(getApplication(), "Welcome back, $name!", Toast.LENGTH_SHORT).show()
    }

    fun logout() {
        repository.logoutUser()
        Toast.makeText(getApplication(), "Signed out", Toast.LENGTH_SHORT).show()
    }

    // External WhatsApp Integration
    fun openWhatsAppChat(context: Context, prefilledMessage: String? = null) {
        val defaultMsg = prefilledMessage
            ?: "Assalam-o-Alaikum, I want to know more about MR. 7 products and services."
        val url = "https://api.whatsapp.com/send?phone=${PaymentConfig.SUPPORT_WHATSAPP_INTL}&text=${URLEncoder.encode(defaultMsg, "UTF-8")}"
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse(url)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp not installed. Contact: ${PaymentConfig.SUPPORT_WHATSAPP}", Toast.LENGTH_LONG).show()
        }
    }

    fun sendOrderNotificationWhatsApp(context: Context, order: OrderEntity) {
        val isCod = order.paymentMethod.contains("Cash", ignoreCase = true) || order.paymentMethod.contains("COD", ignoreCase = true)
        val statusLine = if (isCod) "CASH ON DELIVERY ORDER" else "PAYMENT VERIFICATION REQUIRED"
        val msg = """
            *NEW MR. 7 ORDER*
            ----------------------------
            *Order ID:* ${order.orderId}
            *Customer Name:* ${order.customerName}
            *Phone:* ${order.phoneNumber}
            *Product:* ${order.productName}
            *Quantity:* ${order.quantity}
            *Amount:* Rs. ${order.totalAmount}
            *Payment Method:* ${order.paymentMethod}
            *Transaction ID:* ${order.transactionId}
            *Status:* $statusLine
            ${if (order.notes.isNotBlank()) "*Notes:* ${order.notes}" else ""}
            ----------------------------
            Please confirm my order.
        """.trimIndent()
        openWhatsAppChat(context, msg)
    }

    fun openEmailSupport(context: Context) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:${PaymentConfig.SUPPORT_EMAIL}")
            putExtra(Intent.EXTRA_SUBJECT, "MR. 7 Customer Support Inquiry")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Email: ${PaymentConfig.SUPPORT_EMAIL}", Toast.LENGTH_LONG).show()
        }
    }
}
