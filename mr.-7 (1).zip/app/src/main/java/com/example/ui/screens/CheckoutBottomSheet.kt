package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentConfig
import com.example.data.model.PaymentMethodType
import com.example.ui.theme.*
import com.example.ui.viewmodel.StoreViewModel

@Composable
fun CheckoutBottomSheet(
    checkoutData: StoreViewModel.CheckoutData,
    viewModel: StoreViewModel,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Intercept back button so pressing back ONLY closes checkout and NEVER closes the app
    BackHandler(enabled = true) {
        onDismiss()
    }

    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var customerName by remember { mutableStateOf("") }
    var phoneNumber by remember { mutableStateOf("") }
    var quantity by remember { mutableIntStateOf(checkoutData.quantity) }
    var notes by remember { mutableStateOf("") }
    var transactionId by remember { mutableStateOf("") }
    var screenshotAttached by remember { mutableStateOf(false) }
    var selectedMethod by remember { mutableStateOf<PaymentMethodType>(PaymentMethodType.Easypaisa) }

    val calculatedTotal = if (checkoutData.isCoinCustom) {
        checkoutData.totalAmount
    } else {
        checkoutData.unitPrice * quantity
    }

    val animatedGoldBorder = rememberAnimatedGoldGradient()

    // Full screen overlay with darkened scrim
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xD9141206))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.93f)
                .clickable(enabled = false) {} // Prevent click-through to backdrop
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .border(
                    width = 1.5.dp,
                    brush = animatedGoldBorder,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            colors = CardDefaults.cardColors(containerColor = GlassBg)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
                    .verticalScroll(scrollState)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Top Pull Drag Handle
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .width(44.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(AntiqueGoldBright.copy(alpha = 0.6f))
                        .align(Alignment.CenterHorizontally)
                )

                // Header with explicit Close (X) button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Checkout & Payment",
                            color = Color.White,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "MR. 7 Official TikTok Marketplace",
                            color = WarmChampagne,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                            .testTag("checkout_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                // Order Item Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCardBg),
                    border = BorderStroke(1.dp, GlassCardBorderBrush)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Selected Package",
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = checkoutData.productTitle,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (!checkoutData.isCoinCustom) {
                                // Quantity Stepper
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Qty:",
                                        color = TextSecondary,
                                        fontSize = 13.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(DarkSurfaceVariant)
                                            .clickable { if (quantity > 1) quantity-- },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Remove,
                                            contentDescription = "Decrease",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = "$quantity",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(DarkSurfaceVariant)
                                            .clickable { quantity++ },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Increase",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = "Custom Coins Package",
                                    color = AntiqueGoldBright,
                                    fontSize = 12.sp
                                )
                            }
                            // Total Price
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Total Amount",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Rs. $calculatedTotal",
                                    color = AntiqueGoldBright,
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // Customer Details Form
                Text(
                    text = "1. Customer Information",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("Full Name / TikTok Username *") },
                    placeholder = { Text("e.g. Hamza Malik") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_name_field"),
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AntiqueGoldBright,
                        unfocusedBorderColor = BorderGlass,
                        focusedLabelColor = AntiqueGoldLight,
                        unfocusedLabelColor = TextSecondary,
                        focusedContainerColor = DarkSurfaceVariant,
                        unfocusedContainerColor = DarkSurfaceVariant
                    )
                )

                OutlinedTextField(
                    value = phoneNumber,
                    onValueChange = { input -> phoneNumber = input },
                    label = { Text("Customer WhatsApp / Phone Number *") },
                    placeholder = { Text("03XX-XXXXXXX (Your Own Number)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_phone_field"),
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AntiqueGoldBright,
                        unfocusedBorderColor = BorderGlass,
                        focusedLabelColor = AntiqueGoldLight,
                        unfocusedLabelColor = TextSecondary,
                        focusedContainerColor = DarkSurfaceVariant,
                        unfocusedContainerColor = DarkSurfaceVariant,
                        cursorColor = AntiqueGoldBright
                    )
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Additional Notes / TikTok ID") },
                    placeholder = { Text("Mention TikTok username or specific requests") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AntiqueGoldBright,
                        unfocusedBorderColor = BorderGlass,
                        focusedLabelColor = AntiqueGoldLight,
                        unfocusedLabelColor = TextSecondary,
                        focusedContainerColor = DarkSurfaceVariant,
                        unfocusedContainerColor = DarkSurfaceVariant
                    )
                )

                // Payment Methods Selection
                Text(
                    text = "2. Select Payment Method",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PaymentMethodType.all.forEach { method ->
                        val isSelected = selectedMethod == method
                        val accountDetail = PaymentConfig.getDetail(method)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedMethod = method },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) DarkCardBg else DarkSurfaceVariant
                            ),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) AntiqueGoldBright else BorderGlass
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        RadioButton(
                                            selected = isSelected,
                                            onClick = { selectedMethod = method },
                                            colors = RadioButtonDefaults.colors(
                                                selectedColor = AntiqueGoldBright,
                                                unselectedColor = TextSecondary
                                            )
                                        )
                                        Column {
                                            Text(
                                                text = method.title,
                                                color = Color.White,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = accountDetail.instructions,
                                                color = if (isSelected) WarmChampagne else TextSecondary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                // If selected, show official payment credentials with 1-Tap Copy
                                if (isSelected && method.isManualTransfer) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(containerColor = DarkBg),
                                        border = BorderStroke(1.dp, BorderGold)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(
                                                        text = "Account Title: ${accountDetail.accountTitle}",
                                                        color = TextSecondary,
                                                        fontSize = 11.sp
                                                    )
                                                    Text(
                                                        text = "Account / IBAN Number:",
                                                        color = TextTertiary,
                                                        fontSize = 10.sp
                                                    )
                                                    Text(
                                                        text = accountDetail.accountNumber,
                                                        color = AntiqueGoldBright,
                                                        fontSize = 15.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                                Button(
                                                    onClick = {
                                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                                        clipboard?.setPrimaryClip(
                                                            ClipData.newPlainText("MR7 Account", accountDetail.accountNumber)
                                                        )
                                                        Toast.makeText(context, "Account Number Copied!", Toast.LENGTH_SHORT).show()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = AntiqueGoldBright),
                                                    shape = RoundedCornerShape(8.dp),
                                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                    modifier = Modifier.height(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ContentCopy,
                                                        contentDescription = "Copy",
                                                        tint = Color.Black,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "COPY",
                                                        color = Color.Black,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // If manual method, show Transaction ID and Screenshot upload simulator
                if (selectedMethod.isManualTransfer) {
                    Text(
                        text = "3. Payment Proof & Verification",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    OutlinedTextField(
                        value = transactionId,
                        onValueChange = { transactionId = it },
                        label = { Text("Transaction ID / TRX ID / Reference *") },
                        placeholder = { Text("e.g. 1029384756") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("checkout_trx_id_field"),
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AntiqueGoldBright,
                            unfocusedBorderColor = BorderGlass,
                            focusedLabelColor = AntiqueGoldLight,
                            unfocusedLabelColor = TextSecondary,
                            focusedContainerColor = DarkSurfaceVariant,
                            unfocusedContainerColor = DarkSurfaceVariant
                        )
                    )

                    // Screenshot Upload Box / Simulator
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                screenshotAttached = !screenshotAttached
                                val msg = if (screenshotAttached) "Payment Screenshot attached ✓" else "Screenshot removed"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (screenshotAttached) Color(0x2210B981) else DarkSurfaceVariant
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (screenshotAttached) EmeraldGreen else BorderGlass
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (screenshotAttached) EmeraldGreen else DarkSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (screenshotAttached) Icons.Default.Check else Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = if (screenshotAttached) Color.White else AntiqueGoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (screenshotAttached) "Payment Screenshot Attached (receipt_payment.png)" else "Upload Payment Screenshot",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (screenshotAttached) "Tap to change or remove screenshot" else "Tap to attach payment screenshot receipt",
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // SUBMIT ORDER BUTTON
                Button(
                    onClick = {
                        if (customerName.isBlank()) {
                            Toast.makeText(context, "Please enter your Full Name", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (phoneNumber.isBlank()) {
                            Toast.makeText(context, "Please enter your Phone Number", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (selectedMethod.isManualTransfer && transactionId.isBlank()) {
                            Toast.makeText(context, "Please enter the Transaction ID / Ref Number", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        viewModel.submitOrder(
                            customerName = customerName,
                            phoneNumber = phoneNumber,
                            productName = checkoutData.productTitle,
                            quantity = quantity,
                            totalAmount = calculatedTotal,
                            paymentMethod = selectedMethod.title,
                            transactionId = transactionId.ifBlank { "N/A" },
                            screenshotUri = if (screenshotAttached) "simulated_receipt.png" else null,
                            notes = notes.ifBlank { "" },
                            onSuccess = { order ->
                                onDismiss()
                                viewModel.sendOrderNotificationWhatsApp(context, order)
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_order_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(LiquidGoldGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (selectedMethod == PaymentMethodType.CashOnDelivery) "PLACE COD ORDER VIA WHATSAPP" else "SUBMIT ORDER & CONFIRM ON WHATSAPP",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
