package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Product
import com.example.data.model.ProductCatalog
import com.example.ui.components.GridProductCard
import com.example.ui.components.ShopifyHeroBanner
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StoreViewModel

@Composable
fun HomeScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val filteredProducts by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()
    val wishlistedIds = wishlistItems.map { it.productId }.toSet()

    // Smooth Scrolling Parallax Calculation for Hero Banner
    val parallaxOffset by remember {
        derivedStateOf {
            if (listState.firstVisibleItemIndex == 0) {
                listState.firstVisibleItemScrollOffset * 0.42f
            } else {
                0f
            }
        }
    }

    val animatedGold = rememberAnimatedGoldGradient()

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ============================================
        //   PRESTIGIOUS HERO BANNER CAROUSEL
        // ============================================
        if (searchQuery.isBlank()) {
            item {
                ShopifyHeroBanner(
                    onShopNowClick = { product ->
                        viewModel.startCheckoutForProduct(product)
                    },
                    onWhatsAppClick = { viewModel.openWhatsAppChat(context) },
                    parallaxOffset = parallaxOffset,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)
                )
            }
        }

        // ============================================
        //   CATEGORY FILTER CHIPS
        // ============================================
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ProductCatalog.categories) { category ->
                    val isSelected = selectedCategory == category
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Color.Transparent else DarkSurfaceVariant,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) AntiqueGoldBright else BorderGlass
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectCategory(category) }
                            .testTag("cat_chip_$category")
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) {
                                        Brush.horizontalGradient(
                                            listOf(AntiqueGoldDark, AntiqueGoldBright)
                                        )
                                    } else {
                                        Brush.verticalGradient(
                                            listOf(DarkSurfaceVariant, DarkSurfaceVariant)
                                        )
                                    }
                                )
                                .padding(horizontal = 12.dp, vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = category,
                                color = if (isSelected) Color.Black else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Search results count if searching
        if (searchQuery.isNotBlank()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Results for \"$searchQuery\"",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${filteredProducts.size} found",
                        color = AntiqueGoldBright,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // ============================================
        //   UK ACCOUNTS SECTION (SIDE-BY-SIDE IN ONE ROW)
        // ============================================
        if (searchQuery.isBlank() && (selectedCategory == "All" || selectedCategory == "UK Accounts")) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AntiqueGoldBright)
                        )
                        Text(
                            text = "UK Earning Accounts",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Side-by-side comparison",
                        color = TextTertiary,
                        fontSize = 10.sp
                    )
                }
            }

            // Both UK Account products side-by-side in one row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Left: UK Earning Account (Rs. 1,500)
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.UK_EARNING_BASIC,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.UK_EARNING_BASIC.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.UK_EARNING_BASIC) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.UK_EARNING_BASIC) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.UK_EARNING_BASIC,
                                    wishlistedIds.contains(ProductCatalog.UK_EARNING_BASIC.id)
                                )
                            }
                        )
                    }
                    // Right: PREMIUM UK EARNING PACKAGE (Rs. 2,000)
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.UK_EARNING_PREMIUM,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.UK_EARNING_PREMIUM.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.UK_EARNING_PREMIUM) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.UK_EARNING_PREMIUM) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.UK_EARNING_PREMIUM,
                                    wishlistedIds.contains(ProductCatalog.UK_EARNING_PREMIUM.id)
                                )
                            }
                        )
                    }
                }
            }

            // ============================================
            //   PROMOTIONAL GUARANTEE BANNER
            // ============================================
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = GlassCard),
                    border = BorderStroke(1.5.dp, animatedGold)
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Background glow with warm yellow tones
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0x33FBBF24), Color(0x22CA8A04), Color(0x33FDE047))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(LiquidGoldGradient)
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "MR. 7 GUARANTEE",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Text(
                                    text = "100% Monetization & Safe Coins",
                                    color = WarmChampagne,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Why Creators Choose MR. 7 Store",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "• Official UK Creator Rewards dashboard setup & direct GBP payout help.\n• Live stream gifting coins delivered instantly to your username without passwords.\n• 24/7 dedicated WhatsApp support team for all order inquiries.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        // ============================================
        //   TIKTOK COINS PACKAGES (SIDE-BY-SIDE 2-COLUMN GRID)
        // ============================================
        if (searchQuery.isBlank() && (selectedCategory == "All" || selectedCategory == "TikTok Coins")) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AntiqueGoldBright)
                        )
                        Text(
                            text = "TikTok Coins & Gifting",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "Instant Top-Up",
                        color = AntiqueGoldBright,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Coin Packages Pair 1: 30 Coins (Rs 180) & 70 Coins (Rs 350)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.COINS_30,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.COINS_30.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.COINS_30) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.COINS_30) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.COINS_30,
                                    wishlistedIds.contains(ProductCatalog.COINS_30.id)
                                )
                            }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.COINS_70,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.COINS_70.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.COINS_70) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.COINS_70) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.COINS_70,
                                    wishlistedIds.contains(ProductCatalog.COINS_70.id)
                                )
                            }
                        )
                    }
                }
            }

            // Coin Packages Pair 2: 100 Coins (Rs 500) & 235 Coins (Rs 1000)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.COINS_100,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.COINS_100.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.COINS_100) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.COINS_100) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.COINS_100,
                                    wishlistedIds.contains(ProductCatalog.COINS_100.id)
                                )
                            }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.COINS_235,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.COINS_235.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.COINS_235) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.COINS_235) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.COINS_235,
                                    wishlistedIds.contains(ProductCatalog.COINS_235.id)
                                )
                            }
                        )
                    }
                }
            }

            // Coin Packages Pair 3: 1,000 Coins (Rs 5,000) & Live Gifting Boost (Rs 3,500)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.COINS_1000,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.COINS_1000.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.COINS_1000) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.COINS_1000) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.COINS_1000,
                                    wishlistedIds.contains(ProductCatalog.COINS_1000.id)
                                )
                            }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = ProductCatalog.LIVE_GIFTING_BOOST,
                            isWishlisted = wishlistedIds.contains(ProductCatalog.LIVE_GIFTING_BOOST.id),
                            onCardClick = { viewModel.openProductDetail(ProductCatalog.LIVE_GIFTING_BOOST) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(ProductCatalog.LIVE_GIFTING_BOOST) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    ProductCatalog.LIVE_GIFTING_BOOST,
                                    wishlistedIds.contains(ProductCatalog.LIVE_GIFTING_BOOST.id)
                                )
                            }
                        )
                    }
                }
            }
        }

        // ============================================
        //   CUSTOM COIN CALCULATOR PROMO
        // ============================================
        if (searchQuery.isBlank()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 2.dp)
                        .clickable { viewModel.navigateTo(AppScreen.Coins) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    border = BorderStroke(1.dp, BorderGold)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(
                                model = R.drawable.img_tiktok_coins,
                                contentDescription = "Coins Calculator",
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Column {
                                Text(
                                    text = "Custom Coin Calculator",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Enter any coins (30 to 200,000+) & get instant price",
                                    color = WarmChampagne,
                                    fontSize = 10.sp
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = "Open Calculator",
                            tint = AntiqueGoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // If search query is active, display in 2-column grid pairs
        if (searchQuery.isNotBlank()) {
            val chunked = filteredProducts.chunked(2)
            items(chunked) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        GridProductCard(
                            product = pair[0],
                            isWishlisted = wishlistedIds.contains(pair[0].id),
                            onCardClick = { viewModel.openProductDetail(pair[0]) },
                            onBuyNowClick = { viewModel.startCheckoutForProduct(pair[0]) },
                            onWishlistClick = {
                                viewModel.toggleWishlist(
                                    pair[0],
                                    wishlistedIds.contains(pair[0].id)
                                )
                            }
                        )
                    }
                    if (pair.size > 1) {
                        Box(modifier = Modifier.weight(1f)) {
                            GridProductCard(
                                product = pair[1],
                                isWishlisted = wishlistedIds.contains(pair[1].id),
                                onCardClick = { viewModel.openProductDetail(pair[1]) },
                                onBuyNowClick = { viewModel.startCheckoutForProduct(pair[1]) },
                                onWishlistClick = {
                                    viewModel.toggleWishlist(
                                        pair[1],
                                        wishlistedIds.contains(pair[1].id)
                                    )
                                }
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
