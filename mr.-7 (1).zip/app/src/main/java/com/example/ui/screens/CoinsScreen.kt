package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CoinPackage
import com.example.data.model.CoinPricing
import com.example.ui.theme.*
import com.example.ui.viewmodel.StoreViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun CoinsScreen(
    viewModel: StoreViewModel,
    modifier: Modifier = Modifier
) {
    val customCoinsInput by viewModel.customCoinsInput.collectAsStateWithLifecycle()
    val calculatedPrice by viewModel.calculatedCoinPrice.collectAsStateWithLifecycle()
    val presetAmounts = listOf(30L, 70L, 100L, 235L, 500L, 1000L, 10000L, 100000L, 200000L)
    val numberFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val animatedGold = rememberAnimatedGoldGradient()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ============================================
        //   SLEEK, COMPACT COIN CALCULATOR
        // ============================================
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_coin_calculator_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GlassCard),
                border = BorderStroke(1.5.dp, animatedGold)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    // Header Row with Coin Picture & Title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AsyncImage(
                                model = R.drawable.img_tiktok_coins,
                                contentDescription = "TikTok Coins",
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Column {
                                Text(
                                    text = "Custom Coin Calculator",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Live rate • Instant calculation",
                                    color = WarmChampagne,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x33FDE047))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "BEST RATE",
                                color = AntiqueGoldBright,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presetAmounts) { amount ->
                            val isSelected = customCoinsInput == amount.toString()
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) AntiqueGoldBright else DarkSurfaceVariant,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AntiqueGoldBright else BorderGlass
                                ),
                                modifier = Modifier.clickable {
                                    viewModel.selectCoinPreset(amount)
                                }
                            ) {
                                Text(
                                    text = "${numberFormatter.format(amount)} Coins",
                                    color = if (isSelected) Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Enter Coin Quantity:",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Input Box with clear text
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceVariant)
                            .border(1.dp, BorderGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = AntiqueGoldBright,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                if (customCoinsInput.isEmpty()) {
                                    Text(
                                        text = "e.g. 235, 500, 1000",
                                        color = TextTertiary,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                BasicTextField(
                                    value = customCoinsInput,
                                    onValueChange = { viewModel.updateCoinsInput(it) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("custom_coin_input"),
                                    textStyle = TextStyle(
                                        color = TextPrimary,
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        lineHeight = 24.sp
                                    ),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    cursorBrush = SolidColor(AntiqueGoldBright)
                                )
                            }
                            if (customCoinsInput.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.updateCoinsInput("") },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Calculation & Action Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Calculated Price:",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Rs. ${numberFormatter.format(calculatedPrice)}",
                                color = AntiqueGoldLight,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        // Buy Now Button
                        Button(
                            onClick = {
                                val coins = customCoinsInput.toLongOrNull() ?: 0L
                                viewModel.startCheckoutForCustomCoins(coins, calculatedPrice)
                            },
                            enabled = (customCoinsInput.toLongOrNull() ?: 0L) > 0,
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("calculator_buy_now_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .background(LiquidGoldGradient)
                                    .padding(horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingBag,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "BUY NOW",
                                        color = Color.Black,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ============================================
        //   PRE-CONFIGURED PACKAGES (SIDE-BY-SIDE 2-COLUMN GRID)
        // ============================================
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Standard Packages",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Select any package to buy",
                    color = TextTertiary,
                    fontSize = 10.sp
                )
            }
        }

        val packagePairs = CoinPricing.packages.chunked(2)
        items(packagePairs) { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    CompactCoinGridCard(
                        coinPackage = pair[0],
                        onBuyClick = {
                            viewModel.startCheckoutForCustomCoins(
                                pair[0].coins.toLong(),
                                pair[0].price.toLong()
                            )
                        }
                    )
                }
                if (pair.size > 1) {
                    Box(modifier = Modifier.weight(1f)) {
                        CompactCoinGridCard(
                            coinPackage = pair[1],
                            onBuyClick = {
                                viewModel.startCheckoutForCustomCoins(
                                    pair[1].coins.toLong(),
                                    pair[1].price.toLong()
                                )
                            }
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun CompactCoinGridCard(
    coinPackage: CoinPackage,
    onBuyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedGold = rememberAnimatedGoldGradient()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("coin_pkg_${coinPackage.coins}")
            .clip(RoundedCornerShape(14.dp))
            .border(
                1.dp,
                if (coinPackage.isPopular) animatedGold else GlassCardBorderBrush,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = GlassCard)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
            ) {
                AsyncImage(
                    model = coinPackage.imageRes,
                    contentDescription = "${coinPackage.coins} Coins",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Dark yellowish vignette overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xDD141206)),
                                startY = 30f
                            )
                        )
                )
                if (coinPackage.label != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (coinPackage.isPopular) {
                                    Brush.horizontalGradient(listOf(AntiqueGoldDark, AntiqueGoldBright))
                                } else {
                                    Brush.horizontalGradient(listOf(Color(0xFFEAB308), Color(0xFFFDE047)))
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = coinPackage.label,
                            color = Color.Black,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            // Body
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Text(
                    text = "${coinPackage.coins} TikTok Coins",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Instant ID Delivery",
                    color = WarmChampagne,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Rs. ${coinPackage.price}",
                        color = AntiqueGoldBright,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Button(
                        onClick = onBuyClick,
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .background(
                                    if (coinPackage.isPopular) LiquidGoldGradient else Brush.horizontalGradient(listOf(AntiqueGoldDark, AntiqueGoldBright))
                                )
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "BUY",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }
    }
}
