package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Product
import com.example.data.model.ProductCatalog
import com.example.ui.theme.*
import kotlinx.coroutines.delay

data class HeroSlide(
    val id: String,
    val title: String,
    val subtitle: String,
    val discountBadge: String,
    val promoCode: String,
    val price: String,
    val originalPrice: String?,
    val imageRes: Int,
    val productTarget: Product,
    val ctaText: String
)

@Composable
fun ShopifyHeroBanner(
    onShopNowClick: (Product) -> Unit,
    onWhatsAppClick: () -> Unit,
    parallaxOffset: Float,
    modifier: Modifier = Modifier
) {
    val slides = remember {
        listOf(
            HeroSlide(
                id = "slide_uk_premium",
                title = "PREMIUM UK EARNING SUITE",
                subtitle = "Monetization + Live Stream Unlocked • 120 Free Coins",
                discountBadge = "⚡ 28% OFF FLASH SALE",
                promoCode = "CODE: MR7VIP",
                price = "Rs. 2,000",
                originalPrice = "Rs. 2,800",
                imageRes = R.drawable.img_luxury_promo_banner,
                productTarget = ProductCatalog.UK_EARNING_PREMIUM,
                ctaText = "BUY NOW • RS. 2,000"
            ),
            HeroSlide(
                id = "slide_coins_mega",
                title = "1,000 TIKTOK COINS BUNDLE",
                subtitle = "Send Lions & Universes • Instant User ID Delivery",
                discountBadge = "🔥 30% MEGA SAVINGS",
                promoCode = "LIMITED OFFER",
                price = "Rs. 5,000",
                originalPrice = "Rs. 7,200",
                imageRes = R.drawable.img_hero_banner,
                productTarget = ProductCatalog.COINS_1000,
                ctaText = "CLAIM 30% OFF COINS"
            ),
            HeroSlide(
                id = "slide_uk_starter",
                title = "UK CREATOR REWARDS ACCOUNT",
                subtitle = "Earn in British Pounds (GBP) • 24/7 Dedicated Support",
                discountBadge = "✨ 25% OFF SPECIAL",
                promoCode = "CODE: STARTUK",
                price = "Rs. 1,500",
                originalPrice = "Rs. 2,000",
                imageRes = R.drawable.img_uk_account,
                productTarget = ProductCatalog.UK_EARNING_BASIC,
                ctaText = "GET UK ACCOUNT"
            )
        )
    }

    val pagerState = rememberPagerState(pageCount = { slides.size })
    val animatedGoldBorder = rememberAnimatedGoldGradient()

    // Auto-advance carousel smoothly every 5.2 seconds
    LaunchedEffect(pagerState) {
        while (true) {
            delay(5200)
            try {
                if (!pagerState.isScrollInProgress && slides.isNotEmpty()) {
                    val nextPage = (pagerState.currentPage + 1) % slides.size
                    pagerState.animateScrollToPage(nextPage)
                }
            } catch (e: Exception) {
                // Ignore cancellation on composition exit
            }
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("shopify_hero_carousel"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = GlassCard),
        border = BorderStroke(1.5.dp, animatedGoldBorder)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(265.dp)
                    .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { pageIndex ->
                    val slide = slides[pageIndex]
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Background Hero Graphic loaded via Coil
                        AsyncImage(
                            model = slide.imageRes,
                            contentDescription = slide.title,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    translationY = parallaxOffset * 0.4f
                                    scaleX = 1.08f
                                    scaleY = 1.08f
                                },
                            contentScale = ContentScale.Crop
                        )

                        // Rich Multi-stop Cinematic Dark Vignette with warm yellowish shadow
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0x33141206),
                                            Color(0xCC141206),
                                            Color(0xFE141206)
                                        ),
                                        startY = 0f
                                    )
                                )
                        )

                        // Content Layer
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Top Row: Brand & Promotional Discount Badges
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Discount Pill
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(LiquidGoldGradient)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = slide.discountBadge,
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 0.5.sp
                                    )
                                }

                                // Promo Code Tag
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xAA141206))
                                        .border(1.dp, BorderGold, RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = slide.promoCode,
                                        color = WarmChampagne,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Middle: Typography & Pricing
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = slide.title,
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    lineHeight = 21.sp
                                )
                                Text(
                                    text = slide.subtitle,
                                    color = WarmChampagne,
                                    fontSize = 11.sp,
                                    lineHeight = 14.sp,
                                    maxLines = 2
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                // Pricing showcase
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = slide.price,
                                        color = AntiqueGoldBright,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    if (slide.originalPrice != null) {
                                        Text(
                                            text = slide.originalPrice,
                                            color = TextTertiary,
                                            fontSize = 12.sp,
                                            textDecoration = TextDecoration.LineThrough
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(Color(0x3310B981))
                                            .padding(horizontal = 6.dp, vertical = 1.dp)
                                    ) {
                                        Text(
                                            text = "IN STOCK",
                                            color = EmeraldGreen,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Bottom Action CTAs (BUY NOW & WHATSAPP)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onShopNowClick(slide.productTarget) },
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(40.dp)
                                        .testTag("hero_cta_buy_${slide.id}"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(LiquidGoldGradient),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.ShoppingBag,
                                                contentDescription = null,
                                                tint = Color.Black,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = slide.ctaText,
                                                color = Color.Black,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black,
                                                letterSpacing = 0.5.sp
                                            )
                                        }
                                    }
                                }

                                Button(
                                    onClick = onWhatsAppClick,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp)
                                        .testTag("hero_whatsapp_btn"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Chat,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "WhatsApp",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Interactive Carousel Indicators (Bottom Center)
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    repeat(slides.size) { index ->
                        val isSelected = pagerState.currentPage == index
                        Box(
                            modifier = Modifier
                                .height(4.dp)
                                .width(if (isSelected) 22.dp else 6.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) AntiqueGoldBright else Color(0x66FFFFFF))
                        )
                    }
                }
            }

            // Bottom Trust Badge Ribbon with warm yellow tint
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xE61A1607))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = AntiqueGoldBright,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "5-15 Min Delivery",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Text(text = "•", color = BorderGlass, fontSize = 10.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = EmeraldGreen,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "100% Genuine",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Text(text = "•", color = BorderGlass, fontSize = 10.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SupportAgent,
                        contentDescription = null,
                        tint = AntiqueGoldBright,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "24/7 Helpline",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
