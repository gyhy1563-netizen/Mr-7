package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val customerName: String,
    val phoneNumber: String,
    val productName: String,
    val quantity: Int,
    val totalAmount: Long,
    val paymentMethod: String,
    val transactionId: String,
    val screenshotUri: String? = null,
    val notes: String = "",
    val paymentStatus: String, // "PAYMENT VERIFICATION REQUIRED", "PAID", "COD_PENDING"
    val orderStatus: String,   // "Pending Payment", "Payment Verification", "Processing", "Completed"
    val timestamp: Long = System.currentTimeMillis()
)
