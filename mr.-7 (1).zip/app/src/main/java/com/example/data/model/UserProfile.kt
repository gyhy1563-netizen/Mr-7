package com.example.data.model

import com.example.R

data class UserProfile(
    val id: String = "user_mr7_vip",
    val fullName: String = "Guest Creator",
    val email: String = "Sign in to sync orders",
    val phoneNumber: String = "",
    val isLoggedIn: Boolean = false,
    val vipLevel: Int = 1,
    val vipTitle: String = "VIP Creator Member",
    val currentXp: Int = 250,
    val targetXp: Int = 1000,
    val rewardCoins: Int = 50,
    val avatarRes: Int = R.drawable.img_vip_avatar,
    val memberSince: String = "2026"
) {
    val progressPercent: Float
        get() = (currentXp.toFloat() / targetXp.toFloat()).coerceIn(0f, 1f)
}
