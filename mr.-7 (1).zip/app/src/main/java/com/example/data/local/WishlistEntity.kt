package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wishlist")
data class WishlistEntity(
    @PrimaryKey val productId: String,
    val title: String,
    val category: String,
    val price: Int,
    val imageRes: Int,
    val timestamp: Long = System.currentTimeMillis()
)
