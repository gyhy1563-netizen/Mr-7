package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R

data class Product(
    val id: String,
    val title: String,
    val category: String,
    val price: Int,
    val originalPrice: Int? = null,
    val badge: String? = null,
    val isPopular: Boolean = false,
    @DrawableRes val imageRes: Int,
    val description: String,
    val features: List<String>,
    val rating: Float = 4.9f,
    val reviewCount: Int = 128
)

object ProductCatalog {
    val UK_EARNING_BASIC = Product(
        id = "uk_acc_basic",
        title = "UK Earning Account",
        category = "UK Accounts",
        price = 1500,
        originalPrice = 2000,
        badge = "VERIFIED",
        isPopular = false,
        imageRes = R.drawable.img_uk_account,
        description = "Official UK TikTok Creator Rewards Account with monetization dashboard enabled. Streamlined setup so you can start earning in British Pounds (GBP) directly with dedicated assistance.",
        features = listOf(
            "UK Earning Account",
            "Live feature opening included",
            "Support until earning",
            "Customer support",
            "Professional assistance"
        ),
        rating = 4.8f,
        reviewCount = 142
    )

    val UK_EARNING_PREMIUM = Product(
        id = "uk_acc_premium",
        title = "PREMIUM UK EARNING PACKAGE",
        category = "UK Accounts",
        price = 2000,
        originalPrice = 2800,
        badge = "MOST POPULAR",
        isPopular = true,
        imageRes = R.drawable.img_uk_account,
        description = "Our flagship full-service UK TikTok monetization package. Includes 100% live streaming clearance, Creator Rewards activation, 120 complimentary gift coins, and 1-on-1 priority support until your first cash-out.",
        features = listOf(
            "UK Account",
            "Live feature opening included",
            "Support until earning",
            "120 FREE Coins",
            "Customer support",
            "Premium assistance"
        ),
        rating = 5.0f,
        reviewCount = 289
    )

    val COINS_30 = Product(
        id = "coins_30",
        title = "30 TikTok Coins",
        category = "TikTok Coins",
        price = 180,
        imageRes = R.drawable.img_tiktok_coins,
        description = "Quick starter top-up of 30 TikTok live stream gifting coins. Delivered directly to your TikTok username within minutes.",
        features = listOf("30 TikTok Coins", "Instant Recharge", "No password required", "100% safe & legal"),
        rating = 4.9f,
        reviewCount = 76
    )

    val COINS_70 = Product(
        id = "coins_70",
        title = "70 TikTok Coins",
        category = "TikTok Coins",
        price = 350,
        imageRes = R.drawable.img_tiktok_coins,
        description = "70 TikTok live stream gifting coins package. Perfect for sending roses, hearts, and supporting your favorite streamers.",
        features = listOf("70 TikTok Coins", "Instant Recharge", "User ID delivery", "24/7 WhatsApp help"),
        rating = 4.9f,
        reviewCount = 94
    )

    val COINS_100 = Product(
        id = "coins_100",
        title = "100 TikTok Coins",
        category = "TikTok Coins",
        price = 500,
        imageRes = R.drawable.img_tiktok_coins,
        description = "100 TikTok Coins package at best rate. Boost your stream presence and gift creators without credit card hassles.",
        features = listOf("100 TikTok Coins", "Fast delivery", "Safe transfer", "Live support"),
        rating = 4.9f,
        reviewCount = 185
    )

    val COINS_235 = Product(
        id = "coins_235",
        title = "235 TikTok Coins",
        category = "TikTok Coins",
        price = 1000,
        badge = "HOT DEAL",
        isPopular = true,
        imageRes = R.drawable.img_tiktok_coins,
        description = "235 TikTok Coins special bundle. Ideal for regular battle gifting and leveling up your TikTok badges.",
        features = listOf("235 TikTok Coins", "Bonus rate savings", "Delivery in 5-15 mins", "Support guarantee"),
        rating = 5.0f,
        reviewCount = 210
    )

    val COINS_1000 = Product(
        id = "coins_1000",
        title = "1,000 TikTok Coins",
        category = "TikTok Coins",
        price = 5000,
        badge = "VIP PACK",
        isPopular = true,
        imageRes = R.drawable.img_tiktok_coins,
        description = "1,000 TikTok Coins VIP package. Send big gifts (Lion, Universe, Fireworks) and dominate the live leaderboards.",
        features = listOf("1,000 TikTok Coins", "VIP high volume rate", "Priority fulfillment", "Dedicated agent"),
        rating = 5.0f,
        reviewCount = 330
    )

    val LIVE_GIFTING_BOOST = Product(
        id = "live_gifting_boost",
        title = "Live Stream Gifting & Lion Pack",
        category = "Live Gifting",
        price = 3500,
        badge = "CREATOR CHOICE",
        imageRes = R.drawable.img_tiktok_coins,
        description = "Complete gifting package for live battles and events. Includes custom gifting coordination and account protection.",
        features = listOf("700 Coins included", "Live match support", "Fast battle boost", "VIP support"),
        rating = 4.9f,
        reviewCount = 68
    )

    val allProducts: List<Product> = listOf(
        UK_EARNING_PREMIUM,
        UK_EARNING_BASIC,
        COINS_1000,
        COINS_235,
        COINS_100,
        COINS_70,
        COINS_30,
        LIVE_GIFTING_BOOST
    )

    val categories: List<String> = listOf(
        "All",
        "UK Accounts",
        "TikTok Coins",
        "Live Gifting"
    )
}
