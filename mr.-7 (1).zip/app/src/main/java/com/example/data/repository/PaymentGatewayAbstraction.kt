package com.example.data.repository

sealed class PaymentRequestStatus {
    object Pending : PaymentRequestStatus()
    data class Processing(val referenceId: String) : PaymentRequestStatus()
    data class Successful(val transactionId: String, val paidAmount: Long) : PaymentRequestStatus()
    data class VerificationRequired(val orderId: String, val referenceId: String) : PaymentRequestStatus()
    data class Failed(val reason: String) : PaymentRequestStatus()
}

data class PaymentGatewayRequest(
    val orderId: String,
    val customerName: String,
    val phoneNumber: String,
    val amount: Long,
    val paymentMethod: String,
    val transactionReference: String
)

interface PaymentGatewayProvider {
    suspend fun initiatePayment(request: PaymentGatewayRequest): PaymentRequestStatus
    suspend fun verifyPayment(transactionId: String): PaymentRequestStatus
}

class ManualPaymentGatewayProvider : PaymentGatewayProvider {
    override suspend fun initiatePayment(request: PaymentGatewayRequest): PaymentRequestStatus {
        return PaymentRequestStatus.VerificationRequired(
            orderId = request.orderId,
            referenceId = request.transactionReference
        )
    }

    override suspend fun verifyPayment(transactionId: String): PaymentRequestStatus {
        return PaymentRequestStatus.VerificationRequired(
            orderId = "",
            referenceId = transactionId
        )
    }
}
