package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.OrderEntity
import com.example.data.local.ReviewEntity
import com.example.data.local.WishlistEntity
import com.example.data.model.DefaultReviews
import com.example.data.model.Product
import com.example.data.model.Review
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class StoreRepository(
    private val appDao: AppDao,
    private val paymentGateway: PaymentGatewayProvider = ManualPaymentGatewayProvider()
) {
    private val _currentUser = MutableStateFlow(
        UserProfile(
            fullName = "Guest Creator",
            email = "Sign in to sync orders",
            phoneNumber = "",
            isLoggedIn = false
        )
    )
    val currentUser: StateFlow<UserProfile> = _currentUser.asStateFlow()

    // Orders flow from Room
    val allOrders: Flow<List<OrderEntity>> = appDao.getAllOrders()

    // Wishlist flow from Room
    val wishlistItems: Flow<List<WishlistEntity>> = appDao.getWishlist()

    fun isProductWishlisted(productId: String): Flow<Boolean> =
        appDao.isWishlisted(productId)

    suspend fun toggleWishlist(product: Product, isCurrentlyWishlisted: Boolean) {
        if (isCurrentlyWishlisted) {
            appDao.removeFromWishlist(product.id)
        } else {
            appDao.addToWishlist(
                WishlistEntity(
                    productId = product.id,
                    title = product.title,
                    category = product.category,
                    price = product.price,
                    imageRes = product.imageRes
                )
            )
        }
    }

    // Reviews combining static presets and user-added ones
    fun getReviews(productId: String): Flow<List<Review>> {
        val defaultForProduct = DefaultReviews.items.filter { it.productId == productId }
        return appDao.getReviewsForProduct(productId).map { roomReviews ->
            val mapped = roomReviews.map { entity ->
                Review(
                    id = "local_${entity.id}",
                    productId = entity.productId,
                    author = entity.author,
                    rating = entity.rating,
                    date = entity.date,
                    comment = entity.comment,
                    verified = entity.verified
                )
            }
            mapped + defaultForProduct
        }
    }

    suspend fun addReview(productId: String, author: String, rating: Int, comment: String) {
        val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val dateString = dateFormat.format(Date())
        appDao.insertReview(
            ReviewEntity(
                productId = productId,
                author = author.ifBlank { "Verified Customer" },
                rating = rating,
                date = dateString,
                comment = comment,
                verified = true
            )
        )
    }

    // Order Creation
    suspend fun createOrder(
        customerName: String,
        phoneNumber: String,
        productName: String,
        quantity: Int,
        totalAmount: Long,
        paymentMethod: String,
        transactionId: String,
        screenshotUri: String?,
        notes: String
    ): OrderEntity {
        val randomNum = Random.nextInt(1000, 9999)
        val orderId = "MR7-2026-$randomNum"
        val isCod = paymentMethod.contains("Cash", ignoreCase = true) || paymentMethod.contains("COD", ignoreCase = true)
        val paymentStatus = if (isCod) {
            "PAYMENT PENDING (COD)"
        } else {
            "PAYMENT VERIFICATION REQUIRED"
        }

        val order = OrderEntity(
            orderId = orderId,
            customerName = customerName.trim(),
            phoneNumber = phoneNumber.trim(),
            productName = productName,
            quantity = quantity,
            totalAmount = totalAmount,
            paymentMethod = paymentMethod,
            transactionId = transactionId.trim().ifEmpty { if (isCod) "COD-ORDER" else "MANUAL-TRX" },
            screenshotUri = screenshotUri,
            notes = notes.trim(),
            paymentStatus = paymentStatus,
            orderStatus = "Pending Verification",
            timestamp = System.currentTimeMillis()
        )

        appDao.insertOrder(order)

        // Award reward XP and coins to user profile
        val current = _currentUser.value
        val newXp = (current.currentXp + (totalAmount / 20).toInt()).coerceAtMost(current.targetXp)
        val newCoins = current.rewardCoins + 20
        _currentUser.value = current.copy(
            currentXp = newXp,
            rewardCoins = newCoins
        )

        return order
    }

    fun loginUser(name: String, email: String, phone: String) {
        _currentUser.value = _currentUser.value.copy(
            fullName = name.ifBlank { "VIP TikTok Creator" },
            email = email.ifBlank { "creator@mr7vip.com" },
            phoneNumber = phone.ifBlank { "0300-1234567" },
            isLoggedIn = true,
            vipLevel = 3,
            vipTitle = "Gold Creator Elite",
            currentXp = 850
        )
    }

    fun logoutUser() {
        _currentUser.value = _currentUser.value.copy(
            isLoggedIn = false
        )
    }
}
