package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: String,
    val author: String,
    val rating: Int,
    val date: String,
    val comment: String,
    val verified: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
