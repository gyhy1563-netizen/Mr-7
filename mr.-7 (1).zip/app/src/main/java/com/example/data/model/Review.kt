package com.example.data.model

data class Review(
    val id: String,
    val productId: String,
    val author: String,
    val rating: Int,
    val date: String,
    val comment: String,
    val verified: Boolean = true
)

object DefaultReviews {
    val items = listOf(
        Review(
            id = "rev_1",
            productId = "uk_acc_premium",
            author = "Hamza Malik (Lahore)",
            rating = 5,
            date = "Yesterday",
            comment = "Brother Abdul Rehman provided full UK monetization account within 2 hours! Live streaming option also unlocked. Support is 10/10.",
            verified = true
        ),
        Review(
            id = "rev_2",
            productId = "uk_acc_premium",
            author = "Shahid Afridi Khan (Peshawar)",
            rating = 5,
            date = "3 days ago",
            comment = "Got 120 free coins as promised in the package. Earning dashboard is completely working in pounds. Genuine MR. 7 service!",
            verified = true
        ),
        Review(
            id = "rev_3",
            productId = "uk_acc_basic",
            author = "Usman Tariq (Karachi)",
            rating = 5,
            date = "5 days ago",
            comment = "Very reasonable rate (Rs. 1,500). Best service for TikTok creators in Pakistan.",
            verified = true
        ),
        Review(
            id = "rev_4",
            productId = "coins_1000",
            author = "Zainab Sheikh (Islamabad)",
            rating = 5,
            date = "1 week ago",
            comment = "1000 Coins delivered instantly to my TikTok ID. Live gift animation lion send kiya live battle me!",
            verified = true
        ),
        Review(
            id = "rev_5",
            productId = "coins_235",
            author = "Bilal Ahmed (Multan)",
            rating = 5,
            date = "2 weeks ago",
            comment = "Super fast delivery through Easypaisa. Trusted seller 100%.",
            verified = true
        )
    )
}
