package com.example.data.model

sealed class PaymentMethodType(
    val id: String,
    val title: String,
    val subtitle: String,
    val isManualTransfer: Boolean
) {
    object Easypaisa : PaymentMethodType(
        id = "easypaisa",
        title = "Easypaisa",
        subtitle = "Instant Mobile Wallet Transfer",
        isManualTransfer = true
    )
    object SadaPay : PaymentMethodType(
        id = "sadapay",
        title = "SadaPay",
        subtitle = "Fast digital account transfer",
        isManualTransfer = true
    )
    object MeezanBank : PaymentMethodType(
        id = "meezan",
        title = "Meezan Bank",
        subtitle = "Islamic Banking Direct Transfer",
        isManualTransfer = true
    )
    object CashOnDelivery : PaymentMethodType(
        id = "cod",
        title = "Cash On Delivery (COD)",
        subtitle = "Confirm via WhatsApp & pay on verification",
        isManualTransfer = false
    )

    companion object {
        val all: List<PaymentMethodType> = listOf(
            Easypaisa,
            SadaPay,
            MeezanBank,
            CashOnDelivery
        )
    }
}

data class PaymentAccountDetail(
    val method: PaymentMethodType,
    val accountTitle: String,
    val accountNumber: String,
    val bankName: String? = null,
    val instructions: String
)

object PaymentConfig {
    val EASYPAISA = PaymentAccountDetail(
        method = PaymentMethodType.Easypaisa,
        accountTitle = "Abdul Rehman Ahmad",
        accountNumber = "0348-3025-551",
        instructions = "Send payment to Easypaisa account, copy Transaction ID / Trx ID and upload screenshot below."
    )
    val SADAPAY = PaymentAccountDetail(
        method = PaymentMethodType.SadaPay,
        accountTitle = "Muhammad Yasir Hussain",
        accountNumber = "0309-490-2077",
        instructions = "Send to SadaPay number. Enter reference ID and attach payment receipt."
    )
    val MEEZAN_BANK = PaymentAccountDetail(
        method = PaymentMethodType.MeezanBank,
        accountTitle = "Abdul Rehman Ahmad",
        accountNumber = "00-3 00-11 31 30 3 03",
        bankName = "Meezan Bank Ltd",
        instructions = "Transfer to Meezan Bank account via IBFT / Raast / ATM. Provide receipt reference."
    )
    val COD = PaymentAccountDetail(
        method = PaymentMethodType.CashOnDelivery,
        accountTitle = "Cash On Delivery / WhatsApp Order",
        accountNumber = "0307-7898-599",
        instructions = "For COD / manual verification, we will automatically generate an official order message for WhatsApp."
    )

    fun getDetail(type: PaymentMethodType): PaymentAccountDetail = when (type) {
        PaymentMethodType.Easypaisa -> EASYPAISA
        PaymentMethodType.SadaPay -> SADAPAY
        PaymentMethodType.MeezanBank -> MEEZAN_BANK
        PaymentMethodType.CashOnDelivery -> COD
    }

    // Support helpline
    const val SUPPORT_WHATSAPP = "0307-7898-599"
    const val SUPPORT_WHATSAPP_INTL = "923077898599"
    const val SUPPORT_EMAIL = "mrsaller95@gmail.com"
}
