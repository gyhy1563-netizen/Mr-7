package com.example.data.model

import androidx.annotation.DrawableRes
import com.example.R

data class CoinPackage(
    val coins: Int,
    val price: Int,
    @DrawableRes val imageRes: Int = R.drawable.img_tiktok_coins,
    val label: String? = null,
    val isPopular: Boolean = false
)

object CoinPricing {
    // Configured packages with prominent Image resource references
    val packages = listOf(
        CoinPackage(
            coins = 30,
            price = 180,
            imageRes = R.drawable.img_tiktok_coins,
            label = "STARTER"
        ),
        CoinPackage(
            coins = 70,
            price = 350,
            imageRes = R.drawable.img_tiktok_coins,
            label = "POPULAR"
        ),
        CoinPackage(
            coins = 100,
            price = 500,
            imageRes = R.drawable.img_tiktok_coins,
            label = "TRENDING"
        ),
        CoinPackage(
            coins = 235,
            price = 1000,
            imageRes = R.drawable.img_tiktok_coins,
            label = "BEST VALUE",
            isPopular = true
        ),
        CoinPackage(
            coins = 1000,
            price = 5000,
            imageRes = R.drawable.img_tiktok_coins,
            label = "MEGA SAVINGS",
            isPopular = true
        )
    )

    // Dynamic rate calculation: ~5 PKR per coin with discounts for high volume
    fun calculatePrice(coins: Long): Long {
        return when {
            coins <= 0 -> 0L
            coins == 30L -> 180L
            coins == 70L -> 350L
            coins == 100L -> 500L
            coins == 235L -> 1000L
            coins == 1000L -> 5000L
            coins < 500 -> (coins * 5.0).toLong()
            coins < 5000 -> (coins * 4.9).toLong()
            coins < 50000 -> (coins * 4.75).toLong()
            else -> (coins * 4.6).toLong()
        }
    }
}
