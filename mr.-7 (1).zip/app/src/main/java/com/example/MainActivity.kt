package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.FloatingWhatsApp
import com.example.ui.components.OrderSuccessDialog
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.StoreViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Mr7StoreApp()
            }
        }
    }
}

@Composable
fun Mr7StoreApp(
    viewModel: StoreViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val cartCount by viewModel.cartItemCount.collectAsStateWithLifecycle()
    val wishlistItems by viewModel.wishlistItems.collectAsStateWithLifecycle()
    val activeCheckout by viewModel.activeCheckout.collectAsStateWithLifecycle()
    val lastSubmittedOrder by viewModel.lastSubmittedOrder.collectAsStateWithLifecycle()

    // Global back handling to return to store
    BackHandler(enabled = currentScreen !is AppScreen.Store) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg),
        containerColor = DarkBg,
        topBar = {
            // Only show main header when not on ProductDetailScreen
            if (currentScreen !is AppScreen.ProductDetail) {
                TopHeaderBar(
                    searchQuery = searchQuery,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    cartCount = cartCount,
                    wishlistCount = wishlistItems.size,
                    onCartClick = { viewModel.navigateTo(AppScreen.Profile) },
                    onWishlistClick = { viewModel.navigateTo(AppScreen.Wishlist) },
                    onProfileClick = { viewModel.navigateTo(AppScreen.Profile) },
                    onWhatsAppClick = { viewModel.openWhatsAppChat(context) },
                    modifier = Modifier.statusBarsPadding()
                )
            }
        },
        bottomBar = {
            // Modern Colorful Luxury Navigation Bar with Yellow-Tinted Glassmorphic styling
            if (currentScreen !is AppScreen.ProductDetail) {
                NavigationBar(
                    containerColor = GlassBg,
                    tonalElevation = 8.dp,
                    modifier = Modifier.border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(listOf(Color(0x66FDE047), Color.Transparent)),
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
                ) {
                    // 1. Store
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Store,
                        onClick = { viewModel.navigateTo(AppScreen.Store) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = "Store",
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Store",
                                fontSize = 11.sp,
                                fontWeight = if (currentScreen is AppScreen.Store) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AntiqueGoldBright,
                            selectedTextColor = AntiqueGoldBright,
                            indicatorColor = Color(0x33CA8A04),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_store")
                    )

                    // 2. TikTok Coins & Calculator
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Coins,
                        onClick = { viewModel.navigateTo(AppScreen.Coins) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Coins",
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Coins",
                                fontSize = 11.sp,
                                fontWeight = if (currentScreen is AppScreen.Coins) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AntiqueGoldBright,
                            selectedTextColor = AntiqueGoldBright,
                            indicatorColor = Color(0x33CA8A04),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_coins")
                    )

                    // 3. Wishlist
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Wishlist,
                        onClick = { viewModel.navigateTo(AppScreen.Wishlist) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (wishlistItems.isNotEmpty()) {
                                        Badge(containerColor = HotPink) {
                                            Text(
                                                text = "${wishlistItems.size}",
                                                color = Color.White,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Wishlist",
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = "Wishlist",
                                fontSize = 11.sp,
                                fontWeight = if (currentScreen is AppScreen.Wishlist) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = HotPink,
                            selectedTextColor = HotPink,
                            indicatorColor = DarkSurfaceVariant,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_wishlist")
                    )

                    // 4. VIP Profile & Level
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.Profile,
                        onClick = { viewModel.navigateTo(AppScreen.Profile) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "VIP Profile",
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "VIP ID",
                                fontSize = 11.sp,
                                fontWeight = if (currentScreen is AppScreen.Profile) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AntiqueGoldBright,
                            selectedTextColor = AntiqueGoldBright,
                            indicatorColor = DarkSurfaceVariant,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_profile")
                    )

                    // 5. Help & FAQ
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.SupportFaq,
                        onClick = { viewModel.navigateTo(AppScreen.SupportFaq) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.HelpOutline,
                                contentDescription = "Help",
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "Helpline",
                                fontSize = 11.sp,
                                fontWeight = if (currentScreen is AppScreen.SupportFaq) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldGreen,
                            selectedTextColor = EmeraldGreen,
                            indicatorColor = DarkSurfaceVariant,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_help")
                    )
                }
            }
        },
        floatingActionButton = {
            // Floating WhatsApp quick contact button
            if (currentScreen !is AppScreen.ProductDetail) {
                FloatingWhatsApp(
                    onClick = { viewModel.openWhatsAppChat(context) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is AppScreen.Store -> {
                    HomeScreen(viewModel = viewModel)
                }
                is AppScreen.ProductDetail -> {
                    ProductDetailScreen(
                        product = screen.product,
                        viewModel = viewModel,
                        onBackClick = { viewModel.navigateBack() }
                    )
                }
                is AppScreen.Coins -> {
                    CoinsScreen(viewModel = viewModel)
                }
                is AppScreen.Wishlist -> {
                    WishlistScreen(viewModel = viewModel)
                }
                is AppScreen.Profile -> {
                    ProfileScreen(viewModel = viewModel)
                }
                is AppScreen.SupportFaq -> {
                    FaqContactScreen(viewModel = viewModel)
                }
                is AppScreen.Orders -> {
                    ProfileScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Modal Checkout Sheet (Protected with BackHandler and smooth slide)
    AnimatedVisibility(
        visible = activeCheckout != null,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        activeCheckout?.let { checkoutData ->
            CheckoutBottomSheet(
                checkoutData = checkoutData,
                viewModel = viewModel,
                onDismiss = { viewModel.closeCheckout() }
            )
        }
    }

    // Order Success Confirmation Dialog
    lastSubmittedOrder?.let { order ->
        OrderSuccessDialog(
            order = order,
            viewModel = viewModel,
            onDismiss = { viewModel.dismissOrderConfirmation() }
        )
    }
}
