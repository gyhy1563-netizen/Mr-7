package com.example

import com.example.data.model.CoinPricing
import com.example.data.model.ProductCatalog
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun coinPricing_isAccurate() {
    assertEquals(180L, CoinPricing.calculatePrice(30))
    assertEquals(350L, CoinPricing.calculatePrice(70))
    assertEquals(500L, CoinPricing.calculatePrice(100))
    assertEquals(1000L, CoinPricing.calculatePrice(235))
    assertEquals(5000L, CoinPricing.calculatePrice(1000))
    assertTrue(CoinPricing.calculatePrice(10000) > 0)
  }

  @Test
  fun productCatalog_containsRequiredProducts() {
    val premium = ProductCatalog.allProducts.find { it.id == "uk_acc_premium" }
    assertNotNull(premium)
    assertEquals(2000, premium?.price)
    assertEquals("MOST POPULAR", premium?.badge)

    val basic = ProductCatalog.allProducts.find { it.id == "uk_acc_basic" }
    assertNotNull(basic)
    assertEquals(1500, basic?.price)

    // Verify all products have valid image resource references
    ProductCatalog.allProducts.forEach { product ->
      assertTrue("Product ${product.id} missing image", product.imageRes > 0)
    }

    // Verify all coin packages have valid image resource references
    CoinPricing.packages.forEach { pkg ->
      assertTrue("Coin package ${pkg.coins} missing image", pkg.imageRes > 0)
    }
  }
}
